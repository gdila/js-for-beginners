var results = document.getElementById('resultsBox');
var tigerPic = document.getElementById('myTiger');

var tiger = {
	color: 'orange',
	pattern: 'striped',
	likes: ['taking naps', 'hunting', 'swimming', 'roaring'],
	roar: function() {
		var div = document.createElement('div');
		div.style.fontSize = '3em';
		div.style.color = '#cc0000';
		var divText = document.createTextNode('ROOOOOAAAAAARRR!!!');
		div.appendChild(divText);
		results.innerHTML = '';
		results.appendChild(div);
	},
	walk: function() {
		var leftMarginValue = 0;
		function increaseMargin() {
			leftMarginValue++;
			tigerPic.style.marginLeft = leftMarginValue + 'px';
			if (leftMarginValue === 200) {
				clearInterval(movePic);
				returnPic();
			}
		}
		var movePic = setInterval(function(){increaseMargin()}, 20);
	},
	run: function() {
		var leftMarginValue = 0;
		function increaseMargin() {
			leftMarginValue += 5;
			tigerPic.style.marginLeft = leftMarginValue + 'px';
			if (leftMarginValue === 200) {
				clearInterval(movePic);
				returnPic();
			}
		}
		var movePic = setInterval(function(){increaseMargin()}, 1);
	}
}

function returnPic() {
	setTimeout(function(){tigerPic.style.marginLeft = 0;}, 1000);
}

var colorButton = document.getElementById('color');
colorButton.onclick = function(e) {
	e.preventDefault();
	var colorText = "The color of the tiger is " + tiger.color;
	results.innerHTML = colorText;
}

var patternButton = document.getElementById('pattern');
patternButton.onclick = function(e) {
	e.preventDefault();
	var patternText = "The tiger's coat has a " + tiger.pattern + " pattern.";
	results.innerHTML = patternText;
}

var likesButton = document.getElementById('likes');
likesButton.onclick = function(e) {
	e.preventDefault();
	var p = document.createElement('p');
	var pText = document.createTextNode('The tiger likes:');
	p.appendChild(pText);
	var list = document.createElement('ul');
	for (var i=0; i<tiger.likes.length; i++) {
		var listItem = document.createElement('li');
		var listText = document.createTextNode(tiger.likes[i]);
		listItem.appendChild(listText);
		list.appendChild(listItem);
	}
	results.innerHTML = '';
	results.appendChild(p);
	results.appendChild(list);
}

var roarButton = document.getElementById('roar');
roarButton.onclick = function(e) {
	tiger.roar();
}

var walkButton = document.getElementById('walk');
walkButton.onclick = function(e) {
	tiger.walk();
}

var runButton = document.getElementById('run');
runButton.onclick = function(e) {
	tiger.run();
}